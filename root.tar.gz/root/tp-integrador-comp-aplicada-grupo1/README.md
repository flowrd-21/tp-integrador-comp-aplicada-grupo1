# tp-integrador-comp-aplicada-grupo1
Trabajo práctico integrador grupal. Grupo 1. Integrantes: FLORENCIA RACCIATTI, SOFIA BRUGO,  MARIO ALBERTO ACORIA
